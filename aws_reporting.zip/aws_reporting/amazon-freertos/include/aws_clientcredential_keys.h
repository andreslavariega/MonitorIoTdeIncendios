/*
 * PEM-encoded client certificate
 *
 * Must include the PEM header and footer:
 * "-----BEGIN CERTIFICATE-----"
 * "...base64 data..."
 * "-----END CERTIFICATE-----";
 */
//static const char clientcredentialCLIENT_CERTIFICATE_PEM[] = "Paste client certificate here.";



/*
 * PEM-encoded client private key.
 *
 * Must include the PEM header and footer:
 * "-----BEGIN RSA PRIVATE KEY-----"
 * "...base64 data..."
 * "-----END RSA PRIVATE KEY-----";
 */
//static const char clientcredentialCLIENT_PRIVATE_KEY_PEM[] = "Paste client private key here.";

////////////////////////////////////////////////////////////
/*
* PEM-encoded client certificate
*
* Must include the PEM header and footer:
* "-----BEGIN CERTIFICATE-----"
* "...base64 data..."
* "-----END CERTIFICATE-----";
*/
static const char clientcredentialCLIENT_CERTIFICATE_PEM[] =
"-----BEGIN CERTIFICATE-----\n"
"MIIDWTCCAkGgAwIBAgIUBG9vcNN++NcVjVkg+ldUm54s2qIwDQYJKoZIhvcNAQEL\n"
"BQAwTTFLMEkGA1UECwxCQW1hem9uIFdlYiBTZXJ2aWNlcyBPPUFtYXpvbi5jb20g\n"
"SW5jLiBMPVNlYXR0bGUgU1Q9V2FzaGluZ3RvbiBDPVVTMB4XDTE4MDQwNDAzMjQx\n"
"M1oXDTQ5MTIzMTIzNTk1OVowHjEcMBoGA1UEAwwTQVdTIElvVCBDZXJ0aWZpY2F0\n"
"ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAK56bbXw5VVFR1paWHgK\n"
"MNazmuE8DOWpP3zZht1fqmU4yCyHcAv9whDjd2L6BU3JaRiZeuJ92lpYo3u0XXzP\n"
"L8J8xu1ccSUBItgJGRC+Av9CxTVcLRw4gS6dVc6gEJypGR8iah3tVWijm5ZHsz2j\n"
"LZeZuj+k8VIQR+BWYh9KAzlZoQAVSAYwygGt5aPMB53M/JAwFVflrkTSEWPMDZXP\n"
"aEqR5RAPUhN7YXNL63VyT1Y12HNL2vnLZE/ETBjKNwUahbE56K8s21K5nA3/FMIR\n"
"KdnalzLhSZ3PCG+fNnEE1qcGV8H7xZDZj73IAlYx7l4yODV/j065TOt5sjCTlyZR\n"
"CaECAwEAAaNgMF4wHwYDVR0jBBgwFoAU9bAPz8hfoWnUCR3BtsuZe03DWXUwHQYD\n"
"VR0OBBYEFGkoK0KxuU+VqAyhYe+lSMP2ADLhMAwGA1UdEwEB/wQCMAAwDgYDVR0P\n"
"AQH/BAQDAgeAMA0GCSqGSIb3DQEBCwUAA4IBAQCA1Ww+MJRJsLBnNzwc2TR6cqru\n"
"Ff48iFdI/UohkX1GlAGkzdnEvYpkGOx66d3IrGzlE1uhMyPZjdyw6c2IDguY+wJd\n"
"rEVpQnJ1jZBAUpLRPS8Qzv69NtquUQ4G9uqXvYqihfMyWDq7GTKi5K2uFsfXb61O\n"
"7LyhZsApUsvAEXlw9IFxY8DQDsvl3DScG6rXiSrRDHBGgMIUNFK3fG5c0iQRlRqU\n"
"WOcsbpCJdCXMRQeZa9DijEBsqkXCkBm6GQVGKGl2llFFP63oY6HBJBlRuuekKIx2\n"
"0UVnV87OVWwT+YipO8XK59UcbROu1iXQgig1QggRsGOkgTRAWO0Qf8QMJtq1\n"
"-----END CERTIFICATE-----\n";

/*
* PEM-encoded client private key.
*
* Must include the PEM header and footer:
* "-----BEGIN RSA PRIVATE KEY-----"
* "...base64 data..."
* "-----END RSA PRIVATE KEY-----";
*/
static const char clientcredentialCLIENT_PRIVATE_KEY_PEM[] =
"-----BEGIN RSA PRIVATE KEY-----\n"
"MIIEogIBAAKCAQEArnpttfDlVUVHWlpYeAow1rOa4TwM5ak/fNmG3V+qZTjILIdw\n"
"C/3CEON3YvoFTclpGJl64n3aWlije7RdfM8vwnzG7VxxJQEi2AkZEL4C/0LFNVwt\n"
"HDiBLp1VzqAQnKkZHyJqHe1VaKOblkezPaMtl5m6P6TxUhBH4FZiH0oDOVmhABVI\n"
"BjDKAa3lo8wHncz8kDAVV+WuRNIRY8wNlc9oSpHlEA9SE3thc0vrdXJPVjXYc0va\n"
"+ctkT8RMGMo3BRqFsTnoryzbUrmcDf8UwhEp2dqXMuFJnc8Ib582cQTWpwZXwfvF\n"
"kNmPvcgCVjHuXjI4NX+PTrlM63myMJOXJlEJoQIDAQABAoIBABL8x8uw94QcEfPH\n"
"OTF3CnGTAhvYyR6FGJ+hnIeizYxObZpK8uqbJu9nkap3wvQAIyvGKBVV1NlYJBJm\n"
"QnY+pdfodE2Ibde1E/Gmq8+infjhb0yrR0126LgF7zyZNrWVwWIeAKZZGZ5Vj6z/\n"
"CIaAp4mD9TzP2mMv2mKThAIbr9YhuNebjLArXHhEvu+pcLeMObB97q8QhPydtXW3\n"
"ng3cHg3I6U/sont+85PtFgDOvroSkrmg0zaeqNsBtonBO9YMFiiPs62jb2rDtwIV\n"
"IQ/hbleQtR8FUfaHmALb0PXMsaxu4+C7pK9Cft6R/A+sKcmd3rLFSRCQodVk3Vt1\n"
"eDlHa0ECgYEA22DTV0EHg8Bdw39XcIcOrgtoSyL8ofVdVBOL/euXJz2h3YnBoK4j\n"
"hNdUlXKPNYUGFH0KHDAxx5Kifp9DqGTkdlXGhDRHE8Yk37dzt7y1W16TsFaKONBY\n"
"zimDIrBV5gz3UrqIb2poxfEAj4ICXlncluThv7riQK238E5j4CFxrgUCgYEAy5rK\n"
"503Yj35KRnP7+IsCB/76pWo02wW0IGcvII3bXLFfMP0dy4W9jGOo333DYwM/rI0s\n"
"dylxbd9a5C3eOfDC5yHPIWGEG8AoIH28f3GG8Z9ZZhStwGd3JDfm0O5IKCBIuhhE\n"
"MSV3B4AT4Zyc6rHKD49cWFdVKsAsMZNnb0ZbY+0CgYAVxX4z4phEUwr7I+AhosWq\n"
"MCehjU9VI2yns2jpQkA1/L/bpJg6wg10WYpjaoMb5J+92MrwEThffgXyWwvz4k9q\n"
"DwkshaOoKrnuGd66FVhKQRCXJ3+AM+0cSLJi9u0Pb6n749c2d3D+c/SCSXzCsFhc\n"
"AUsGJB3gHV1r09vFmowVoQKBgFQEmF5CvW7ZSoUwL3YsxrXN/lhsL0uCWwZUDhp8\n"
"71ycxQ9OJBFsKv/X0EQJfatKF+h4iTTTIT+Zv8QROXbnZ0ZBqVu5Be79qJFf0X01\n"
"t93VR+rb9adECuIjP1hQO+5zBA/nG5y8PRYXQB0Fp6shmqQ5IH5D650smBANJ82/\n"
"Vs8xAoGAEvmEE+XVBrZO0w5jQXzSBRs8zPY1bXteQ0zmRcjfQ0dh58MqCvfm7tRh\n"
"L3BcsvhdLInr/Ro6FPI/oCwFNMPmmcDhKOCvYoEW0yMu5ToYuuysbk95bONtzOI2\n"
"ZiBZA16NMmcZsA+alRPcKokwo0bTvHBL9/2cmHZGJeiyCjcP9Xg=\n"
"-----END RSA PRIVATE KEY-----\n";

